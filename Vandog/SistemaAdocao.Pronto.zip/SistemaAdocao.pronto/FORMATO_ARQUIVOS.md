# Etapa 4 — Manipulação de arquivos

## O que foi implementado

Os cadastros (animais, ONGs, doadores pessoa física e adotantes) são gravados em arquivos **CSV**.
Assim, os dados continuam disponíveis depois de fechar e executar o sistema de novo.

A persistência segue o modelo **DAO** (Data Access Object) usado em aula (`ClienteDAO` / `ICliente`):
cada cadastro tem uma interface e uma classe DAO que lê e grava o seu arquivo com
`FileReader`/`BufferedReader` e `FileWriter`/`PrintWriter`.

| Pacote / Classe | Função |
|---|---|
| `dados/` | Pacote que guarda os arquivos `.csv` (um por cadastro) e a pasta `fotos`. |
| `persistencia.IAnimal`, `IOng`, `IDoador`, `IAdotante` | **Interfaces** do CRUD: `salvar`, `listar`, `atualizar`, `excluir`. |
| `persistencia.AnimalDAO`, `OngDAO`, `DoadorDAO`, `AdotanteDAO` | **Classes que implementam as interfaces**: transformam objeto ↔ linha do CSV. |
| `persistencia.FotoPersistencia` | Copia a foto escolhida para `src/dados/fotos/animal_ID.ext`, lê e apaga as imagens. |
| `visao.ImagemUtil` | Mostra a foto num `JLabel`, redimensionada sem distorcer. |

Como cada DAO funciona (igual ao `ClienteDAO`):

- **`salvar(objeto)`**: gera o próximo ID (maior ID do arquivo + 1), coloca no objeto com `setId`
  e **acrescenta** uma linha no fim do arquivo.
- **`listar()`**: lê o arquivo linha por linha, separa os campos com `split(";")` e monta os objetos.
- **`atualizar(objeto)`**: lê tudo, troca o registro que tem o mesmo ID e **regrava** o arquivo inteiro.
- **`excluir(id)`**: lê tudo, remove o registro com aquele ID e **regrava** o arquivo inteiro.

Não existe lista guardada na memória: toda operação lê o arquivo de novo, então o que aparece na
tela é sempre o que está gravado.

## CRUD

Cada cadastro (animal, ONG, doador e adotante) tem as quatro operações:

| Operação | Na tela | No controller | No DAO (interface) |
|---|---|---|---|
| **C**reate (criar) | botão **CADASTRAR** | `cadastrar(dto)` | `salvar(objeto)` |
| **R**ead (ler) | lista na própria tela / tabela do **Exibir** e botão **BUSCAR** (pelo ID) | `listar()` e `buscarPorId(id)` | `listar()` |
| **U**pdate (alterar) | **BUSCAR** → mudar os campos → **ALTERAR** (no animal também pelo botão ADOTAR do Exibir) | `atualizar(dto)` | `atualizar(objeto)` |
| **D**elete (excluir) | **BUSCAR** → **EXCLUIR** (pede confirmação; no animal também apaga a foto) | `excluir(id)` | `excluir(id)` |

Depois de **CADASTRAR**, **ALTERAR** ou **EXCLUIR**, os campos são limpos automaticamente e a tela
fica pronta para um novo cadastro. O **CADASTRAR** sempre cria um registro novo (com ID novo); para
mudar um registro existente use **BUSCAR** e depois **ALTERAR**.

## Onde ficam os arquivos

No pacote `dados`, dentro de `src` (aparece em **Source Packages** no NetBeans):

```
src/dados/animais.csv
src/dados/ongs.csv
src/dados/doadores.csv
src/dados/adotantes.csv
src/dados/fotos/        ← fotos dos animais (animal_1.jpg, animal_2.png, ...)
```

O caminho é relativo à pasta do projeto (`src/dados/...`), por isso o programa deve ser executado pelo NetBeans.

## Formato escolhido: CSV

Escolhemos **CSV** porque:

- é texto simples, que pode ser aberto no Bloco de Notas ou no Excel para conferência;
- cada objeto vira uma linha e cada atributo vira uma coluna, o que combina com as listas do sistema;
- não depende de nenhuma biblioteca externa.

Regras do arquivo:

- **Separador `;` (ponto e vírgula)**. Por isso **não use `;` dentro dos textos** (nome, descrição...),
  senão a linha fica com colunas a mais.
- **Sem linha de cabeçalho**: cada linha é um registro, começando pelo ID.
- Valores lógicos são gravados como `true`/`false`; o status do animal como o nome do enum
  (`DISPONIVEL`, `EM_ANALISE`, `ADOTADO`).
- O **ID** de cada registro é gerado pelo DAO: maior ID que já está no arquivo + 1.
  Cada arquivo tem a sua própria contagem (pode existir o doador 1 e a ONG 1).

Exemplo de `animais.csv`:

```
1;Rex;M;Grande;Caramelo;true;false;Dócil;DISPONIVEL;src/dados/fotos/animal_1.png;0;2;0
2;Mia;F;Pequeno;Preta;true;true;Muito carinhosa;ADOTADO;;3;0;1
```

Colunas de cada arquivo (nessa ordem):

- `animais.csv`: id; nome; sexo; porte; cor; castrado; vacinado; descricao; status; foto; idAdotante; idDoador; idOng
- `ongs.csv`: id; nome; telefone; email; razaoSocial; cnpj; nomeResponsavel; descricao; instagram; verificada
- `doadores.csv`: id; nome; telefone; email; razaoSocial; cpf; motivoDoacao
- `adotantes.csv`: id; nome; telefone; email; cpf; tipoMoradia; outrosAnimais; experiencia

Arquivos do formato antigo (com linha de cabeçalho `id;...` e menos colunas no animal) continuam
sendo lidos: o cabeçalho é ignorado e as colunas que faltam ficam como `0`/vazias. Na próxima
gravação o arquivo já fica no formato novo.

## Fotos dos animais

- Na tela de cadastro, o botão **ESCOLHER FOTO** abre um seletor que aceita jpg, jpeg, png, gif e bmp, e mostra uma prévia.
- Ao clicar em **CADASTRAR**, o animal é salvo (o DAO gera o ID) e depois a imagem é **copiada** para
  `src/dados/fotos/animal_ID.extensão`. No CSV fica gravado somente o caminho (coluna `foto`).
  A imagem não vai para dentro do CSV, porque o CSV é texto e a imagem é um arquivo binário.
- A foto é opcional: sem foto, a coluna fica vazia.
- Na tela **Exibir**, ao clicar em um animal da tabela, a foto aparece no quadro da esquerda.
- Ao **EXCLUIR** o animal, a foto dele também é apagada da pasta.

## Tratamento de erros

- **Arquivo inexistente ou erro de leitura**: o `listar()` do DAO trata a `IOException`, mostra a
  mensagem no console (`DAO : Erro ao ler: ...`) e devolve a lista vazia, igual ao `ClienteDAO`.
- **Erro de gravação** (`IOException`): a tela mostra "Erro ao salvar no arquivo" com a mensagem do erro.
- **Dados inválidos** (dono/adotante que não confere, campos obrigatórios): o controller lança
  `IllegalArgumentException` e a tela mostra a mensagem; nada é gravado.
- **Foto inválida**: se o arquivo escolhido não for uma imagem, aparece uma mensagem e ele não é aceito.
  Se a cópia da foto falhar, o animal fica cadastrado sem foto e o usuário é avisado. Se a foto
  sumir da pasta, a tela Exibir mostra "Sem foto" em vez de dar erro.

# Organização em MVC + DTO

O projeto segue o padrão **MVC** (Model-View-Controller) com **DTO** (Data Transfer Object) e **DAO**,
no mesmo formato do modelo `ClienteController` / `ICliente` / `ClienteDAO`:

| Camada | Pacote | O que faz |
|---|---|---|
| **View** (visão) | `visao` | Telas Swing. Só lê/mostra campos e conversa com os controllers usando DTOs. Não usa `model` nem `persistencia` diretamente. |
| **DTO** | `dto` | `AnimalDTO`, `OngDTO`, `DoadorDTO`, `AdotanteDTO`: só carregam os dados entre a tela e o controller. |
| **Controller** | `controller` | `AnimalController`, `OngController`, `DoadorController`, `AdotanteController`: convertem DTO ↔ model e chamam o DAO. |
| **Model** | `model` | Classes de domínio (`Animal`, `Ong`, `PessoaFisica`, `Adotante`...). |
| **DAO** (persistência) | `persistencia` | Interfaces `IAnimal`, `IOng`, `IDoador`, `IAdotante` e as classes `AnimalDAO`, `OngDAO`, `DoadorDAO`, `AdotanteDAO`. |

Fluxo de um cadastro: **tela** monta o DTO → **controller** `cadastrar(dto)` cria o objeto do `model` →
**DAO** `salvar(objeto)` gera o ID e grava no CSV.

Cada controller cria o seu DAO no construtor (`this.ongDAO = new OngDAO();`) e tem:
`cadastrar(dto)`, `listar()`, `buscarPorId(id)`, `atualizar(dto)`, `excluir(id)` e `getProximoId()`
(este último só para a tela mostrar qual ID o próximo cadastro vai receber).

# Adoção (animal ↔ adotante)

Na tela **Exibir**, selecione um animal com status `DISPONIVEL`, digite o **Nome** e o **CPF** do adotante
nos campos embaixo da tabela e clique em **ADOTAR**. O sistema procura o adotante pelo CPF e confere se o
nome é o dele; se não conferir, aparece um erro e nada muda. Se conferir, o animal passa para `ADOTADO` e
guarda o ID do adotante na coluna `idAdotante` do `animais.csv` (`0` = ainda não adotado). A tabela do
Exibir mostra o nome de quem adotou na coluna **Adotante**.

- Só animais `DISPONIVEL` podem ser adotados (não dá para adotar o mesmo animal duas vezes).
- Alterar o animal na tela de cadastro não apaga quem adotou.
- **Confirmação por nome + CPF**: o `AnimalController.adotar` compara só os números do CPF (tanto faz digitar
  com ou sem pontos) e o nome sem diferenciar maiúsculas/minúsculas.

# Dono do animal (animal ↔ doador ou ONG)

Na tela **Cadastro de Animal**, ao **CADASTRAR** e ao **ALTERAR** é obrigatório informar o **Dono** e um documento:
- **CPF**, se o dono é uma pessoa: o sistema procura entre os doadores da tela **Cadastro Pessoal**
  e guarda o ID na coluna `idDoador`;
- **CNPJ**, se o dono é uma ONG: o sistema procura entre as ONGs da tela **Cadastro ONG**
  e guarda o ID na coluna `idOng`.

Preencha só um dos dois. O nome digitado precisa ser o do cadastro encontrado; se não conferir, aparece um erro e
o animal não é salvo. As duas colunas são separadas porque doadores e ONGs têm contagens de ID diferentes
(o doador 1 e a ONG 1 são cadastros diferentes). `0` = não é desse tipo / dono não informado (animais antigos).
O **BUSCAR** preenche Dono e CPF (ou CNPJ) com os dados do dono.
