package dto;
public class DoadorDTO {

    private final int id;
    private final String nome;
    private final String telefone;
    private final String email;
    private final String razaoSocial;
    private final String cpf;
    private final String motivoDoacao;

    public DoadorDTO(int id, String nome, String telefone, String email, String razaoSocial, String cpf,
            String motivoDoacao) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
        this.razaoSocial = razaoSocial;
        this.cpf = cpf;
        this.motivoDoacao = motivoDoacao;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getEmail() {
        return email;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public String getCpf() {
        return cpf;
    }

    public String getMotivoDoacao() {
        return motivoDoacao;
    }
}
