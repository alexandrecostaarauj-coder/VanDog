package dto;

public class AdotanteDTO {

    private final int id;
    private final String nome;
    private final String telefone;
    private final String email;
    private final String cpf;
    private final String tipoMoradia;
    private final boolean outrosAnimais;
    private final String experiencia;

    public AdotanteDTO(int id, String nome, String telefone, String email, String cpf, String tipoMoradia,
            boolean outrosAnimais, String experiencia) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
        this.cpf = cpf;
        this.tipoMoradia = tipoMoradia;
        this.outrosAnimais = outrosAnimais;
        this.experiencia = experiencia;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getEmail() {
        return email;
    }

    public String getCpf() {
        return cpf;
    }

    public String getTipoMoradia() {
        return tipoMoradia;
    }

    public boolean isOutrosAnimais() {
        return outrosAnimais;
    }

    public String getExperiencia() {
        return experiencia;
    }
}
