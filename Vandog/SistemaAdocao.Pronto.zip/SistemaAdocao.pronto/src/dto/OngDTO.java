package dto;
public class OngDTO {

    private final int id;
    private final String nome;
    private final String telefone;
    private final String email;
    private final String razaoSocial;
    private final String cnpj;
    private final String nomeResponsavel;
    private final String descricao;
    private final String ig;
    private final boolean verificada;

    public OngDTO(int id, String nome, String telefone, String email, String razaoSocial, String cnpj,
            String nomeResponsavel, String descricao, String ig, boolean verificada) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
        this.razaoSocial = razaoSocial;
        this.cnpj = cnpj;
        this.nomeResponsavel = nomeResponsavel;
        this.descricao = descricao;
        this.ig = ig;
        this.verificada = verificada;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getEmail() {
        return email;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public String getCnpj() {
        return cnpj;
    }

    public String getNomeResponsavel() {
        return nomeResponsavel;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getIg() {
        return ig;
    }

    public boolean isVerificada() {
        return verificada;
    }
}
