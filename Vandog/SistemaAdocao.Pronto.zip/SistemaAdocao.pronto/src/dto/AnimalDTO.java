package dto;

public class AnimalDTO {

    private final int id;
    private final String nome;
    private final String sexo;
    private final String porte;
    private final String cor;
    private final boolean castrado;
    private final boolean vacinado;
    private final String descricao;
    private final String status;
    private final String foto;
    private final int idAdotante;
    private final String nomeDono;
    private final String cpfDono; 
    private final String cnpjDono; 

    public AnimalDTO(int id, String nome, String sexo, String porte, String cor, boolean castrado,
            boolean vacinado, String descricao, String status, String foto, int idAdotante,
            String nomeDono, String cpfDono, String cnpjDono) {
        this.id = id;
        this.nome = nome;
        this.sexo = sexo;
        this.porte = porte;
        this.cor = cor;
        this.castrado = castrado;
        this.vacinado = vacinado;
        this.descricao = descricao;
        this.status = status;
        this.foto = foto;
        this.idAdotante = idAdotante;
        this.nomeDono = nomeDono;
        this.cpfDono = cpfDono;
        this.cnpjDono = cnpjDono;
    }

    public String getCnpjDono() {
        return cnpjDono;
    }

    public String getNomeDono() {
        return nomeDono;
    }

    public String getCpfDono() {
        return cpfDono;
    }

    public int getIdAdotante() {
        return idAdotante;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getSexo() {
        return sexo;
    }

    public String getPorte() {
        return porte;
    }

    public String getCor() {
        return cor;
    }

    public boolean isCastrado() {
        return castrado;
    }

    public boolean isVacinado() {
        return vacinado;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getStatus() {
        return status;
    }

    public String getFoto() {
        return foto;
    }
}
