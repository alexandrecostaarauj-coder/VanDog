package controller;

import dto.AdotanteDTO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import model.Adotante;
import persistencia.AdotanteDAO;
import persistencia.IAdotante;

/**
 *
 * @author isabf
 */

public class AdotanteController {

    private final IAdotante adotanteDAO;

    public AdotanteController() {
        this.adotanteDAO = new AdotanteDAO();
    }

    public void cadastrar(AdotanteDTO dto) throws IOException {

        Adotante adotante = new Adotante(
                dto.getCpf(),
                dto.getTipoMoradia(),
                dto.isOutrosAnimais(),
                dto.getExperiencia(),
                0,
                dto.getNome(),
                dto.getTelefone(),
                dto.getEmail()
        );

        adotanteDAO.salvar(adotante);
    }

    public List<AdotanteDTO> listar() throws IOException {

        List<Adotante> adotantes = adotanteDAO.listar();

        List<AdotanteDTO> listaDTO = new ArrayList<>();

        for (Adotante adotante : adotantes) {

            AdotanteDTO adotanteDTO = new AdotanteDTO(
                    adotante.getId(),
                    adotante.getNome(),
                    adotante.getTelefone(),
                    adotante.getEmail(),
                    adotante.getCpf(),
                    adotante.getTipoMoradia(),
                    adotante.isOutrosAnimais(),
                    adotante.getExperiencia()
            );

            listaDTO.add(adotanteDTO);
        }

        return listaDTO;
    }

    public AdotanteDTO buscarPorId(int id) throws IOException {

        for (AdotanteDTO adotante : listar()) {
            if (adotante.getId() == id) {
                return adotante;
            }
        }

        return null;
    }

    public void atualizar(AdotanteDTO dto) throws IOException {

        Adotante adotante = new Adotante(
                dto.getCpf(),
                dto.getTipoMoradia(),
                dto.isOutrosAnimais(),
                dto.getExperiencia(),
                0,
                dto.getNome(),
                dto.getTelefone(),
                dto.getEmail()
        );
        adotante.setId(dto.getId());

        adotanteDAO.atualizar(adotante);
    }

    public void excluir(int id) throws IOException {
        adotanteDAO.excluir(id);
    }

    public int getProximoId() throws IOException {

        int maiorId = 0;

        for (AdotanteDTO adotante : listar()) {
            if (adotante.getId() > maiorId) {
                maiorId = adotante.getId();
            }
        }

        return maiorId + 1;
    }
}
