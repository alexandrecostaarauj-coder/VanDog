package controller;

import dto.DoadorDTO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import model.PessoaFisica;
import persistencia.DoadorDAO;
import persistencia.IDoador;

/**
 *
 * @author isabf
 */

public class DoadorController {

    private final IDoador doadorDAO;

    public DoadorController() {
        this.doadorDAO = new DoadorDAO();
    }

    public void cadastrar(DoadorDTO dto) throws IOException {

        PessoaFisica doador = new PessoaFisica(
                dto.getCpf(),
                dto.getMotivoDoacao(),
                dto.getRazaoSocial(),
                dto.getNome(),
                dto.getTelefone(),
                dto.getEmail()
        );

        doadorDAO.salvar(doador);
    }

    public List<DoadorDTO> listar() throws IOException {

        List<PessoaFisica> doadores = doadorDAO.listar();

        List<DoadorDTO> listaDTO = new ArrayList<>();

        for (PessoaFisica doador : doadores) {

            DoadorDTO doadorDTO = new DoadorDTO(
                    doador.getId(),
                    doador.getNome(),
                    doador.getTelefone(),
                    doador.getEmail(),
                    doador.getRazaoSocial(),
                    doador.getCpf(),
                    doador.getMotivoDoacao()
            );

            listaDTO.add(doadorDTO);
        }

        return listaDTO;
    }

    public DoadorDTO buscarPorId(int id) throws IOException {

        for (DoadorDTO doador : listar()) {
            if (doador.getId() == id) {
                return doador;
            }
        }

        return null;
    }

    public void atualizar(DoadorDTO dto) throws IOException {

        PessoaFisica doador = new PessoaFisica(
                dto.getCpf(),
                dto.getMotivoDoacao(),
                dto.getRazaoSocial(),
                dto.getNome(),
                dto.getTelefone(),
                dto.getEmail()
        );
        doador.setId(dto.getId());

        doadorDAO.atualizar(doador);
    }

    public void excluir(int id) throws IOException {
        doadorDAO.excluir(id);
    }
    public int getProximoId() throws IOException {

        int maiorId = 0;

        for (DoadorDTO doador : listar()) {
            if (doador.getId() > maiorId) {
                maiorId = doador.getId();
            }
        }

        return maiorId + 1;
    }
}
