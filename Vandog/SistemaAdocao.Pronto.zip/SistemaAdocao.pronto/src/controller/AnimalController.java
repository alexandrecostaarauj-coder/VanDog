package controller;

import dto.AnimalDTO;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import model.Adotante;
import model.Animal;
import model.Ong;
import model.PessoaFisica;
import model.StatusAdocao;
import persistencia.AdotanteDAO;
import persistencia.AnimalDAO;
import persistencia.DoadorDAO;
import persistencia.FotoPersistencia;
import persistencia.IAdotante;
import persistencia.IAnimal;
import persistencia.IDoador;
import persistencia.IOng;
import persistencia.OngDAO;

/**
 *
 * @author isabf
 */

public class AnimalController {

    private final IAnimal animalDAO;
    private final IDoador doadorDAO;
    private final IOng ongDAO;
    private final IAdotante adotanteDAO;

    public AnimalController() {
        this.animalDAO = new AnimalDAO();
        this.doadorDAO = new DoadorDAO();
        this.ongDAO = new OngDAO();
        this.adotanteDAO = new AdotanteDAO();
    }

    public void cadastrar(AnimalDTO dto) throws IOException {

        Animal animal = new Animal(
                dto.getNome(),
                dto.getSexo(),
                dto.getPorte(),
                dto.getCor(),
                dto.isCastrado(),
                dto.isVacinado(),
                dto.getDescricao(),
                StatusAdocao.valueOf(dto.getStatus())
        );

        definirDono(animal, dto.getNomeDono(), dto.getCpfDono(), dto.getCnpjDono());

        animalDAO.salvar(animal);
        if (dto.getFoto() != null) {
            try {
                animal.setFoto(FotoPersistencia.salvarFoto(new File(dto.getFoto()), animal.getId()));
                animalDAO.atualizar(animal);
            } catch (IOException ex) {
                throw new IOException("Animal cadastrado, mas a foto não pôde ser copiada: " + ex.getMessage());
            }
        }
    }

    public List<AnimalDTO> listar() throws IOException {

        List<Animal> animais = animalDAO.listar();
        List<PessoaFisica> doadores = doadorDAO.listar();
        List<Ong> ongs = ongDAO.listar();

        List<AnimalDTO> listaDTO = new ArrayList<>();

        for (Animal animal : animais) {

            String nomeDono = "";
            String cpfDono = "";
            String cnpjDono = "";

            for (PessoaFisica doador : doadores) {
                if (doador.getId() == animal.getIdDoador()) {
                    nomeDono = doador.getNome();
                    cpfDono = doador.getCpf();
                }
            }
            for (Ong ong : ongs) {
                if (ong.getId() == animal.getIdOng()) {
                    nomeDono = ong.getNome();
                    cnpjDono = ong.getCnpj();
                }
            }

            AnimalDTO animalDTO = new AnimalDTO(
                    animal.getId(),
                    animal.getNome(),
                    animal.getSexo(),
                    animal.getPorte(),
                    animal.getCor(),
                    animal.isCastrado(),
                    animal.isVacinado(),
                    animal.getDescricao(),
                    animal.getStatusAdocao().name(),
                    animal.getFoto(),
                    animal.getIdAdotante(),
                    nomeDono,
                    cpfDono,
                    cnpjDono
            );

            listaDTO.add(animalDTO);
        }

        return listaDTO;
    }

    public AnimalDTO buscarPorId(int id) throws IOException {

        for (AnimalDTO animal : listar()) {
            if (animal.getId() == id) {
                return animal;
            }
        }

        return null;
    }

    public void atualizar(AnimalDTO dto) throws IOException {

        Animal atual = buscarAnimal(dto.getId());
        if (atual == null) {
            throw new IllegalArgumentException("Animal com ID " + dto.getId() + " não encontrado.");
        }

        Animal animal = new Animal(
                dto.getNome(),
                dto.getSexo(),
                dto.getPorte(),
                dto.getCor(),
                dto.isCastrado(),
                dto.isVacinado(),
                dto.getDescricao(),
                StatusAdocao.valueOf(dto.getStatus())
        );
        animal.setId(dto.getId());
        animal.setIdAdotante(atual.getIdAdotante());

        definirDono(animal, dto.getNomeDono(), dto.getCpfDono(), dto.getCnpjDono());
        String fotoAntiga = atual.getFoto();
        animal.setFoto(fotoAntiga);
        if (dto.getFoto() != null && !dto.getFoto().equals(fotoAntiga)) {
            animal.setFoto(FotoPersistencia.salvarFoto(new File(dto.getFoto()), animal.getId()));
            if (fotoAntiga != null && !fotoAntiga.equals(animal.getFoto())) {
                FotoPersistencia.excluirFoto(fotoAntiga);
            }
        }

        animalDAO.atualizar(animal);
    }

    public void excluir(int id) throws IOException {

        Animal animal = buscarAnimal(id);

        animalDAO.excluir(id);
        if (animal != null && animal.getFoto() != null) {
            FotoPersistencia.excluirFoto(animal.getFoto());
        }
    }
    public String adotar(int idAnimal, String nomeDigitado, String cpfDigitado) throws IOException {

        Animal animal = buscarAnimal(idAnimal);
        if (animal == null) {
            throw new IllegalArgumentException("Animal com ID " + idAnimal + " não encontrado.");
        }
        if (animal.getStatusAdocao() != StatusAdocao.DISPONIVEL) {
            throw new IllegalArgumentException("Esse animal não está disponível para adoção.");
        }

        String nomeInformado = nomeDigitado == null ? "" : nomeDigitado.trim();
        String cpfInformado = cpfDigitado == null ? "" : cpfDigitado.replaceAll("\\D", "");
        if (nomeInformado.isEmpty() || cpfInformado.isEmpty()) {
            throw new IllegalArgumentException("Digite o nome e o CPF do adotante.");
        }

        Adotante adotante = null;
        for (Adotante a : adotanteDAO.listar()) {
            String cpfCadastro = a.getCpf() == null ? "" : a.getCpf().replaceAll("\\D", "");
            if (cpfCadastro.equals(cpfInformado)) {
                adotante = a;
                break;
            }
        }

        if (adotante == null || !adotante.getNome().trim().equalsIgnoreCase(nomeInformado)) {
            throw new IllegalArgumentException("Nome e CPF não conferem com nenhum adotante cadastrado.");
        }

        animal.setIdAdotante(adotante.getId());
        animal.setStatusAdocao(StatusAdocao.ADOTADO);

        animalDAO.atualizar(animal);

        return adotante.getNome();
    }
    public int getProximoId() throws IOException {

        int maiorId = 0;

        for (Animal animal : animalDAO.listar()) {
            if (animal.getId() > maiorId) {
                maiorId = animal.getId();
            }
        }

        return maiorId + 1;
    }

    public String[] getExtensoesFoto() {
        return FotoPersistencia.EXTENSOES;
    }

    public boolean isImagemValida(String caminho) {
        return FotoPersistencia.lerImagem(caminho) != null;
    }

    private Animal buscarAnimal(int id) throws IOException {

        for (Animal animal : animalDAO.listar()) {
            if (animal.getId() == id) {
                return animal;
            }
        }

        return null;
    }
    private void definirDono(Animal animal, String nomeDigitado, String cpfDigitado, String cnpjDigitado) throws IOException {

        String nomeInformado = nomeDigitado == null ? "" : nomeDigitado.trim();
        String cpfInformado = cpfDigitado == null ? "" : cpfDigitado.replaceAll("\\D", "");
        String cnpjInformado = cnpjDigitado == null ? "" : cnpjDigitado.replaceAll("\\D", "");

        if (nomeInformado.isEmpty()) {
            throw new IllegalArgumentException("Digite o nome do dono do animal.");
        }
        if (!cpfInformado.isEmpty() && !cnpjInformado.isEmpty()) {
            throw new IllegalArgumentException("Preencha só o CPF (pessoa) ou só o CNPJ (ONG), não os dois.");
        }

        if (!cpfInformado.isEmpty()) {
            for (PessoaFisica doador : doadorDAO.listar()) {
                String cpfCadastro = doador.getCpf() == null ? "" : doador.getCpf().replaceAll("\\D", "");
                if (cpfCadastro.equals(cpfInformado)) {
                    if (doador.getNome().trim().equalsIgnoreCase(nomeInformado)) {
                        animal.setIdDoador(doador.getId());
                        animal.setIdOng(0);
                        return;
                    }
                    break;
                }
            }
            throw new IllegalArgumentException("Dono e CPF não conferem com nenhum doador cadastrado.");
        }

        if (!cnpjInformado.isEmpty()) {
            for (Ong ong : ongDAO.listar()) {
                String cnpjCadastro = ong.getCnpj() == null ? "" : ong.getCnpj().replaceAll("\\D", "");
                if (cnpjCadastro.equals(cnpjInformado)) {
                    if (ong.getNome().trim().equalsIgnoreCase(nomeInformado)) {
                        animal.setIdOng(ong.getId());
                        animal.setIdDoador(0);
                        return;
                    }
                    break;                }
            }
            throw new IllegalArgumentException("Dono e CNPJ não conferem com nenhuma ONG cadastrada.");
        }

        throw new IllegalArgumentException("Digite o CPF (se o dono for uma pessoa) ou o CNPJ (se for uma ONG).");
    }
}
