package controller;

import dto.OngDTO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import model.Ong;
import persistencia.IOng;
import persistencia.OngDAO;

/**
 *
 * @author isabf
 */
public class OngController {

    private final IOng ongDAO;

    public OngController() {
        this.ongDAO = new OngDAO();
    }

    public void cadastrar(OngDTO dto) throws IOException {

        Ong ong = new Ong(
                dto.getCnpj(),
                dto.getNomeResponsavel(),
                dto.getDescricao(),
                dto.getIg(),
                dto.isVerificada(),
                dto.getRazaoSocial(),
                dto.getNome(),
                dto.getTelefone(),
                dto.getEmail()
        );

        ongDAO.salvar(ong);
    }

    public List<OngDTO> listar() throws IOException {

        List<Ong> ongs = ongDAO.listar();

        List<OngDTO> listaDTO = new ArrayList<>();

        for (Ong ong : ongs) {

            OngDTO ongDTO = new OngDTO(
                    ong.getId(),
                    ong.getNome(),
                    ong.getTelefone(),
                    ong.getEmail(),
                    ong.getRazaoSocial(),
                    ong.getCnpj(),
                    ong.getNomeResponsavel(),
                    ong.getDescricao(),
                    ong.getIg(),
                    ong.isVerificada()
            );

            listaDTO.add(ongDTO);
        }

        return listaDTO;
    }

    public OngDTO buscarPorId(int id) throws IOException {

        for (OngDTO ong : listar()) {
            if (ong.getId() == id) {
                return ong;
            }
        }

        return null;
    }

    public void atualizar(OngDTO dto) throws IOException {

        Ong ong = new Ong(
                dto.getCnpj(),
                dto.getNomeResponsavel(),
                dto.getDescricao(),
                dto.getIg(),
                dto.isVerificada(),
                dto.getRazaoSocial(),
                dto.getNome(),
                dto.getTelefone(),
                dto.getEmail()
        );
        ong.setId(dto.getId());

        ongDAO.atualizar(ong);
    }

    public void excluir(int id) throws IOException {
        ongDAO.excluir(id);
    }
    public int getProximoId() throws IOException {

        int maiorId = 0;

        for (OngDTO ong : listar()) {
            if (ong.getId() > maiorId) {
                maiorId = ong.getId();
            }
        }

        return maiorId + 1;
    }
}
