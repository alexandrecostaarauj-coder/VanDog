package persistencia;

import java.io.IOException;
import java.util.List;
import model.PessoaFisica;

/**
 *
 * @author isabf
 */
public interface IDoador {

    public void salvar(PessoaFisica pessoaFisica) throws IOException;

    public List<PessoaFisica> listar() throws IOException;

    public void atualizar(PessoaFisica pessoaFisicaAlterado) throws IOException;

    public void excluir(int id) throws IOException;
}
