package persistencia;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import model.Animal;
import model.StatusAdocao;

/**
 *
 * @author isabf
 */

public class AnimalDAO implements IAnimal {

    private String arquivo = "";

    public AnimalDAO() {
        arquivo = "src/dados/animais.csv";
    }

    @Override
    public void salvar(Animal animal) throws IOException {

        int proximoId = gerarProximoId();

        animal.setId(proximoId);

        FileWriter fw = new FileWriter(arquivo, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(
                animal.getId() + ";"
                + animal.getNome() + ";"
                + animal.getSexo() + ";"
                + animal.getPorte() + ";"
                + animal.getCor() + ";"
                + animal.isCastrado() + ";"
                + animal.isVacinado() + ";"
                + animal.getDescricao() + ";"
                + animal.getStatusAdocao() + ";"
                + (animal.getFoto() == null ? "" : animal.getFoto()) + ";"
                + animal.getIdAdotante() + ";"
                + animal.getIdDoador() + ";"
                + animal.getIdOng()
        );

        pw.close();
    }

    @Override
    public List<Animal> listar() {

        List<Animal> animais = new ArrayList<>();

        try {
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            String linha;

            while ((linha = br.readLine()) != null) {
                if (linha.isBlank() || linha.startsWith("id;")) {
                    continue;
                }
                String[] dados = linha.split(";", -1);

                Animal animal = new Animal(
                        dados[1],
                        dados[2],
                        dados[3],
                        dados[4],
                        Boolean.parseBoolean(dados[5]),
                        Boolean.parseBoolean(dados[6]),
                        dados[7],
                        StatusAdocao.valueOf(dados[8])
                );

                animal.setId(Integer.parseInt(dados[0]));

                if (dados.length > 9 && !dados[9].isEmpty()) {
                    animal.setFoto(dados[9]);
                }
                if (dados.length > 10 && !dados[10].isEmpty()) {
                    animal.setIdAdotante(Integer.parseInt(dados[10]));
                }
                if (dados.length > 11 && !dados[11].isEmpty()) {
                    animal.setIdDoador(Integer.parseInt(dados[11]));
                }
                if (dados.length > 12 && !dados[12].isEmpty()) {
                    animal.setIdOng(Integer.parseInt(dados[12]));
                }

                animais.add(animal);
            }

            br.close();

        } catch (IOException e) {
            System.out.println(
                    "DAO : Erro ao ler: " + e.getMessage()
            );
        }

        return animais;
    }

    @Override
    public void atualizar(Animal animalAlterado) {

        List<Animal> animais = listar();

        for (int i = 0; i < animais.size(); i++) {

            if (animais.get(i).getId() == animalAlterado.getId()) {
                animais.set(i, animalAlterado);
            }
        }

        regravar(animais);
    }

    @Override
    public void excluir(int id) {

        List<Animal> animais = listar();

        animais.removeIf(
                animal -> animal.getId() == id
        );

        regravar(animais);
    }

    private void regravar(List<Animal> animais) {

        try {
            FileWriter fw = new FileWriter(arquivo);
            PrintWriter pw = new PrintWriter(fw);

            for (Animal animal : animais) {

                pw.println(
                        animal.getId() + ";"
                        + animal.getNome() + ";"
                        + animal.getSexo() + ";"
                        + animal.getPorte() + ";"
                        + animal.getCor() + ";"
                        + animal.isCastrado() + ";"
                        + animal.isVacinado() + ";"
                        + animal.getDescricao() + ";"
                        + animal.getStatusAdocao() + ";"
                        + (animal.getFoto() == null ? "" : animal.getFoto()) + ";"
                        + animal.getIdAdotante() + ";"
                        + animal.getIdDoador() + ";"
                        + animal.getIdOng()
                );
            }

            pw.close();

        } catch (IOException e) {
            System.out.println(
                    "DAO : Erro ao regravar: " + e.getMessage()
            );
        }
    }

    private int gerarProximoId() {

        List<Animal> animais = listar();

        int maiorId = 0;

        for (Animal animal : animais) {

            if (animal.getId() > maiorId) {
                maiorId = animal.getId();
            }
        }

        return maiorId + 1;
    }
}
