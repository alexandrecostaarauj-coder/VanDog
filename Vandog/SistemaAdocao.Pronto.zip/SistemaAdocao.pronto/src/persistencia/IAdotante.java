package persistencia;

import java.io.IOException;
import java.util.List;
import model.Adotante;

/**
 *
 * @author isabf
 */
public interface IAdotante {

    public void salvar(Adotante adotante) throws IOException;

    public List<Adotante> listar() throws IOException;

    public void atualizar(Adotante adotanteAlterado) throws IOException;

    public void excluir(int id) throws IOException;
}
