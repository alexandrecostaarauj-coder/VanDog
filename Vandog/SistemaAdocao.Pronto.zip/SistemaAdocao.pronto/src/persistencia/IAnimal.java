package persistencia;

import java.io.IOException;
import java.util.List;
import model.Animal;

/**
 *
 * @author isabf
 */
public interface IAnimal {

    public void salvar(Animal animal) throws IOException;

    public List<Animal> listar() throws IOException;

    public void atualizar(Animal animalAlterado) throws IOException;

    public void excluir(int id) throws IOException;
}
