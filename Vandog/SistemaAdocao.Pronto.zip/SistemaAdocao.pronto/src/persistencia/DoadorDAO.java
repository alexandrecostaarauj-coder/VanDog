package persistencia;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import model.PessoaFisica;

/**
 *
 * @author isabf
 */

public class DoadorDAO implements IDoador {

    private String arquivo = "";

    public DoadorDAO() {
        arquivo = "src/dados/doadores.csv";
    }

    @Override
    public void salvar(PessoaFisica doador) throws IOException {

        int proximoId = gerarProximoId();

        doador.setId(proximoId);

        FileWriter fw = new FileWriter(arquivo, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(
                doador.getId() + ";"
                + doador.getNome() + ";"
                + doador.getTelefone() + ";"
                + doador.getEmail() + ";"
                + doador.getRazaoSocial() + ";"
                + doador.getCpf() + ";"
                + doador.getMotivoDoacao()
        );

        pw.close();
    }

    @Override
    public List<PessoaFisica> listar() {

        List<PessoaFisica> doadores = new ArrayList<>();

        try {
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            String linha;

            while ((linha = br.readLine()) != null) {
                if (linha.isBlank() || linha.startsWith("id;")) {
                    continue;
                }
                String[] dados = linha.split(";", -1);

                PessoaFisica doador = new PessoaFisica(
                        dados[5],
                        dados[6],
                        dados[4],
                        dados[1],
                        dados[2],
                        dados[3]
                );

                doador.setId(Integer.parseInt(dados[0]));

                doadores.add(doador);
            }

            br.close();

        } catch (IOException e) {
            System.out.println(
                    "DAO : Erro ao ler: " + e.getMessage()
            );
        }

        return doadores;
    }

    @Override
    public void atualizar(PessoaFisica doadorAlterado) {

        List<PessoaFisica> doadores = listar();

        for (int i = 0; i < doadores.size(); i++) {

            if (doadores.get(i).getId() == doadorAlterado.getId()) {
                doadores.set(i, doadorAlterado);
            }
        }

        regravar(doadores);
    }

    @Override
    public void excluir(int id) {

        List<PessoaFisica> doadores = listar();

        doadores.removeIf(
                doador -> doador.getId() == id
        );

        regravar(doadores);
    }

    private void regravar(List<PessoaFisica> doadores) {

        try {
            FileWriter fw = new FileWriter(arquivo);
            PrintWriter pw = new PrintWriter(fw);

            for (PessoaFisica doador : doadores) {

                pw.println(
                        doador.getId() + ";"
                        + doador.getNome() + ";"
                        + doador.getTelefone() + ";"
                        + doador.getEmail() + ";"
                        + doador.getRazaoSocial() + ";"
                        + doador.getCpf() + ";"
                        + doador.getMotivoDoacao()
                );
            }

            pw.close();

        } catch (IOException e) {
            System.out.println(
                    "DAO : Erro ao regravar: " + e.getMessage()
            );
        }
    }

    private int gerarProximoId() {

        List<PessoaFisica> doadores = listar();

        int maiorId = 0;

        for (PessoaFisica doador : doadores) {

            if (doador.getId() > maiorId) {
                maiorId = doador.getId();
            }
        }

        return maiorId + 1;
    }
}
