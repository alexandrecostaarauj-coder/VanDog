package persistencia;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import model.Adotante;

/**
 *
 * @author isabf
 */

public class AdotanteDAO implements IAdotante {

    private String arquivo = "";

    public AdotanteDAO() {
        arquivo = "src/dados/adotantes.csv";
    }

    @Override
    public void salvar(Adotante adotante) throws IOException {

        int proximoId = gerarProximoId();

        adotante.setId(proximoId);

        FileWriter fw = new FileWriter(arquivo, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(
                adotante.getId() + ";"
                + adotante.getNome() + ";"
                + adotante.getTelefone() + ";"
                + adotante.getEmail() + ";"
                + adotante.getCpf() + ";"
                + adotante.getTipoMoradia() + ";"
                + adotante.isOutrosAnimais() + ";"
                + adotante.getExperiencia()
        );

        pw.close();
    }

    @Override
    public List<Adotante> listar() {

        List<Adotante> adotantes = new ArrayList<>();

        try {
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            String linha;

            while ((linha = br.readLine()) != null) {
                if (linha.isBlank() || linha.startsWith("id;")) {
                    continue;
                }
                String[] dados = linha.split(";", -1);

                Adotante adotante = new Adotante(
                        dados[4],
                        dados[5],
                        Boolean.parseBoolean(dados[6]),
                        dados[7],
                        0,
                        dados[1],
                        dados[2],
                        dados[3]
                );

                adotante.setId(Integer.parseInt(dados[0]));

                adotantes.add(adotante);
            }

            br.close();

        } catch (IOException e) {
            System.out.println(
                    "DAO : Erro ao ler: " + e.getMessage()
            );
        }

        return adotantes;
    }

    @Override
    public void atualizar(Adotante adotanteAlterado) {

        List<Adotante> adotantes = listar();

        for (int i = 0; i < adotantes.size(); i++) {

            if (adotantes.get(i).getId() == adotanteAlterado.getId()) {
                adotantes.set(i, adotanteAlterado);
            }
        }

        regravar(adotantes);
    }

    @Override
    public void excluir(int id) {

        List<Adotante> adotantes = listar();

        adotantes.removeIf(
                adotante -> adotante.getId() == id
        );

        regravar(adotantes);
    }

    private void regravar(List<Adotante> adotantes) {

        try {
            FileWriter fw = new FileWriter(arquivo);
            PrintWriter pw = new PrintWriter(fw);

            for (Adotante adotante : adotantes) {

                pw.println(
                        adotante.getId() + ";"
                        + adotante.getNome() + ";"
                        + adotante.getTelefone() + ";"
                        + adotante.getEmail() + ";"
                        + adotante.getCpf() + ";"
                        + adotante.getTipoMoradia() + ";"
                        + adotante.isOutrosAnimais() + ";"
                        + adotante.getExperiencia()
                );
            }

            pw.close();

        } catch (IOException e) {
            System.out.println(
                    "DAO : Erro ao regravar: " + e.getMessage()
            );
        }
    }

    private int gerarProximoId() {

        List<Adotante> adotantes = listar();

        int maiorId = 0;

        for (Adotante adotante : adotantes) {

            if (adotante.getId() > maiorId) {
                maiorId = adotante.getId();
            }
        }

        return maiorId + 1;
    }
}
