package persistencia;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import model.Ong;

/**
 *
 * @author isabf
 */
public class OngDAO implements IOng {

    private String arquivo = "";

    public OngDAO() {
        arquivo = "src/dados/ongs.csv";
    }

    @Override
    public void salvar(Ong ong) throws IOException {

        int proximoId = gerarProximoId();

        ong.setId(proximoId);

        FileWriter fw = new FileWriter(arquivo, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(
                ong.getId() + ";"
                + ong.getNome() + ";"
                + ong.getTelefone() + ";"
                + ong.getEmail() + ";"
                + ong.getRazaoSocial() + ";"
                + ong.getCnpj() + ";"
                + ong.getNomeResponsavel() + ";"
                + ong.getDescricao() + ";"
                + ong.getIg() + ";"
                + ong.isVerificada()
        );

        pw.close();
    }

    @Override
    public List<Ong> listar() {
        List<Ong> ongs = new ArrayList<>();
        try {
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);
            String linha;
            while ((linha = br.readLine()) != null) {
                if (linha.isBlank() || linha.startsWith("id;")) {
                    continue;
                }
                String[] dados = linha.split(";", -1);
                Ong ong = new Ong(
                        dados[5],
                        dados[6],
                        dados[7],
                        dados[8],
                        Boolean.parseBoolean(dados[9]),
                        dados[4],
                        dados[1],
                        dados[2],
                        dados[3]
                );
                ong.setId(Integer.parseInt(dados[0]));

                ongs.add(ong);
            }
            br.close();

        } catch (IOException e) {
            System.out.println(
                    "DAO : Erro ao ler: " + e.getMessage()
            );
        }

        return ongs;
    }
    @Override
    public void atualizar(Ong ongAlterada) {

        List<Ong> ongs = listar();

        for (int i = 0; i < ongs.size(); i++) {

            if (ongs.get(i).getId() == ongAlterada.getId()) {
                ongs.set(i, ongAlterada);
            }
        }
        regravar(ongs);
    }
    @Override
    public void excluir(int id) {

        List<Ong> ongs = listar();

        ongs.removeIf(
                ong -> ong.getId() == id
        );
        regravar(ongs);
    }
    private void regravar(List<Ong> ongs) {
        try {
            FileWriter fw = new FileWriter(arquivo);
            PrintWriter pw = new PrintWriter(fw);
            
            for (Ong ong : ongs) {

                pw.println(
                        ong.getId() + ";"
                        + ong.getNome() + ";"
                        + ong.getTelefone() + ";"
                        + ong.getEmail() + ";"
                        + ong.getRazaoSocial() + ";"
                        + ong.getCnpj() + ";"
                        + ong.getNomeResponsavel() + ";"
                        + ong.getDescricao() + ";"
                        + ong.getIg() + ";"
                        + ong.isVerificada()
                );
            }

            pw.close();

        } catch (IOException e) {
            System.out.println(
                    "DAO : Erro ao regravar: " + e.getMessage()
            );
        }
    }

    private int gerarProximoId() {
        List<Ong> ongs = listar();
        int maiorId = 0;
        for (Ong ong : ongs) {
            if (ong.getId() > maiorId) {
                maiorId = ong.getId();
            }
        }
        return maiorId + 1;
    }
}
