package persistencia;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import javax.imageio.ImageIO;


public final class FotoPersistencia {

    public static final Path PASTA_FOTOS = Paths.get("src", "dados", "fotos");


    public static final String[] EXTENSOES = {"jpg", "jpeg", "png", "gif", "bmp"};

    private FotoPersistencia() {
    }

    public static String salvarFoto(File origem, int idAnimal) throws IOException {
        if (lerImagem(origem.getPath()) == null) {
            throw new IOException("o arquivo escolhido não é uma imagem válida.");
        }

        Files.createDirectories(PASTA_FOTOS);

        String nome = "animal_" + idAnimal + "." + extensao(origem.getName());
        Path destino = PASTA_FOTOS.resolve(nome);
        Files.copy(origem.toPath(), destino, StandardCopyOption.REPLACE_EXISTING);

        return destino.toString().replace('\\', '/');
    }

    public static BufferedImage lerImagem(String caminho) {
        if (caminho == null || caminho.isBlank()) {
            return null;
        }
        try {
            File arquivo = new File(caminho);
            if (!arquivo.isFile()) {
                return null;
            }
            return ImageIO.read(arquivo);
        } catch (IOException ex) {
            return null;
        }
    }

        public static void excluirFoto(String caminho) {
        if (caminho == null || caminho.isBlank()) {
            return;
        }
        try {
            Files.deleteIfExists(Paths.get(caminho));
        } catch (IOException ex) {
          
        }
    }

    private static String extensao(String nomeArquivo) {
        int ponto = nomeArquivo.lastIndexOf('.');
        if (ponto < 0 || ponto == nomeArquivo.length() - 1) {
            return "png";
        }
        return nomeArquivo.substring(ponto + 1).toLowerCase();
    }
}
