package persistencia;

import java.io.IOException;
import java.util.List;
import model.Ong;

/**
 *
 * @author isabf
 */
public interface IOng {

    public void salvar(Ong ong) throws IOException;

    public List<Ong> listar() throws IOException;

    public void atualizar(Ong ongAlterado) throws IOException;

    public void excluir(int id) throws IOException;
}
