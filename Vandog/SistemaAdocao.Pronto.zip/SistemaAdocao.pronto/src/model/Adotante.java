/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Adotante extends Usuario {

    private String cpf;
    private String tipoMoradia;
    private boolean outrosAnimais;
    private String experiencia;

    public Adotante(String cpf, String tipoMoradia, boolean outrosAnimais, String experiencia, int id, String nome, String telefone, String email) {
        super(nome, telefone, email);
        this.cpf = cpf;
        this.tipoMoradia = tipoMoradia;
        this.outrosAnimais = outrosAnimais;
        this.experiencia = experiencia;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        if (cpf == null || cpf.trim().isEmpty()) {
            throw new IllegalArgumentException("O CPF não pode ficar vazio!");
        }

        if (!cpf.matches("\\d{11}")) {
            throw new IllegalArgumentException("O CPF deve conter 11 números!");
        }
        this.cpf = cpf;
    }


    public String getTipoMoradia() {
        return tipoMoradia;
    }

    public void setTipoMoradia(String tipoMoradia) {
        if (tipoMoradia == null || tipoMoradia.trim().isEmpty()) {
            throw new IllegalArgumentException("O tipo de moradia não pode ficar vazio!");
        }
        this.tipoMoradia = tipoMoradia;
    }

    public boolean isOutrosAnimais() {
        return outrosAnimais;
    }

    public void setOutrosAnimais(boolean outrosAnimais) {
        this.outrosAnimais = outrosAnimais;
    }

    public String getExperiencia() {
        return experiencia;
    }

    public void setExpericencia(String experiencia) {
        if (experiencia == null || experiencia.trim().isEmpty()) {
            throw new IllegalArgumentException("A experiência não pode ficar vazia!");
        }
        this.experiencia = experiencia;
    }

    @Override
    public String toString() {
        return "Adotante{" + "cpf=" + cpf + ", tipoMoradia=" + tipoMoradia + ", outrosAnimais=" + outrosAnimais + ", experiencia=" + experiencia + '}';
    }

}
