/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author isabf
 */
public class Ong extends Doador {

    private String cnpj;
    private String nomeResponsavel;
    private String descricao;
    private String ig;
    private boolean verificada;

    public Ong(String cnpj, String nomeResponsavel, String descricao, String ig, boolean verificada, String razaoSocial,String nome, String telefone, String email) {
        super(razaoSocial, nome, telefone, email);
        setCnpj(cnpj);
        this.nomeResponsavel = nomeResponsavel;
        this.descricao = descricao;
        this.ig = ig;
        this.verificada = verificada;
    }

    public void solicitarVerificacao() {

    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        if (cnpj == null || cnpj.trim().isEmpty()) {
            throw new IllegalArgumentException("O cnpj não pode ficar vazio!");
        }
        this.cnpj = cnpj;
    }

    public String getNomeResponsavel() {
        return nomeResponsavel;
    }

    public void setNomeResponsavel(String nomeResponsavel) {
        if (nomeResponsavel == null || nomeResponsavel.trim().isEmpty()) {
            throw new IllegalArgumentException("O nome do responsavel não pode ficar vazio!");
        }
        this.nomeResponsavel = nomeResponsavel;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        if (descricao == null || descricao.trim().isEmpty()) {
            throw new IllegalArgumentException("A descricao não pode ficar vazia!");
        }
        this.descricao = descricao;
    }

    public String getIg() {
        return ig;
    }

    public void setIg(String ig) {
        this.ig = ig;
    }

    public boolean isVerificada() {
        return verificada;
    }

    public void setVerificada(boolean verificada) {
        this.verificada = verificada;
    }

    @Override
    public String toString() {
        return "Ong{" + "cnpj=" + cnpj + ", nomeResponsavel=" + nomeResponsavel + ", descricao=" + descricao + ", ig=" + ig + ", verificada=" + verificada + '}';
    }

}
