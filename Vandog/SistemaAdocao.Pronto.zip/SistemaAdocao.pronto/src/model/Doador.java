/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author isabf
 */
public class Doador extends Usuario {
    
    private String razaoSocial;

    public Doador(String razaoSocial, String nome, String telefone, String email) {
        super(nome, telefone, email);
        this.razaoSocial = razaoSocial;
    }
   
    public void cadastrarAnimal(){
        
    }
    
    public void editarAnimal(){
        
    }
    
    public void removerAnimal(){
        
    }
    
    public void avaliarSolicitacao(){
        
    }
    
    public String getRazaoSocial() {
    return razaoSocial;
}
    
}
