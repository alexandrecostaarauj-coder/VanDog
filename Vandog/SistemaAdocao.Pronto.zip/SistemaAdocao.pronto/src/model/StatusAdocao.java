
package model;
public enum StatusAdocao {
    DISPONIVEL,
    EM_ANALISE,
    ADOTADO,
    
}
