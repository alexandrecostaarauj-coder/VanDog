/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author isabf
 */
public class PessoaFisica extends Doador {

    private String cpf;
    private String motivoDoacao;

    public PessoaFisica(String cpf, String motivoDoacao, String razaoSocial, String nome, String telefone, String email) {
        super(razaoSocial, nome, telefone, email);
        this.cpf = cpf;
        this.motivoDoacao = motivoDoacao;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        if (cpf == null || cpf.trim().isEmpty()) {
            throw new IllegalArgumentException("O CPF não pode ficar vazio!");
        }

        if (!cpf.matches("\\d{11}")) {
            throw new IllegalArgumentException("O CPF deve conter 11 números!");
        }
        this.cpf = cpf;
    }

    public String getMotivoDoacao() {
        return motivoDoacao;
    }

    public void setMotivoDoacao(String motivoDoacao) {
        if (motivoDoacao == null || motivoDoacao.trim().isEmpty()) {
            throw new IllegalArgumentException("O motivo do doacao não pode ficar vazio!");
        }
        this.motivoDoacao = motivoDoacao;
    }

    @Override
    public String toString() {
        return "PessoaFisica{" + "cpf=" + cpf + ", motivoDoacao=" + motivoDoacao + '}';
    }

    
    
}
