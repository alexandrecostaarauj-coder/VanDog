package model;
public class Adocao {

    private String dataSolicitacao;
    private String dataConclusao;
    private String observacoes;
    private Adotante adotante;
    private Animal animal;

    public Adocao(String dataSolicitacao, String dataConclusao, String observacoes, Adotante adotante, Animal animal) {
        this.dataSolicitacao = dataSolicitacao;
        this.dataConclusao = dataConclusao;
        this.observacoes = observacoes;
        this.adotante = adotante;
        this.animal = animal;
    }

    public String getDataSolicitacao() {
        return dataSolicitacao;
    }

    public void setDataSolicitacao(String dataSolicitacao) {
        if (dataSolicitacao == null || dataSolicitacao.trim().isEmpty()) {
            throw new IllegalArgumentException("A data de solicitação não pode ficar vazia!");
        }

        if (!dataSolicitacao.matches("\\d{2}/\\d{2}/\\d{4}")) {
            throw new IllegalArgumentException("Informe a data no formato DD/MM/AAAA!");
        }
        this.dataSolicitacao = dataSolicitacao;
    }

    public String getDataConclusao() {
        return dataConclusao;
    }

    public void setDataConclusao(String dataConclusao) {
        if (dataConclusao == null || dataConclusao.trim().isEmpty()) {
            throw new IllegalArgumentException("A data de conclusão não pode ficar vazia!");
        }

        if (!dataSolicitacao.matches("\\d{2}/\\d{2}/\\d{4}")) {
            throw new IllegalArgumentException("Informe a data no formato DD/MM/AAAA!");
        }
        this.dataConclusao = dataConclusao;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        if (observacoes == null || observacoes.trim().isEmpty()) {
            throw new IllegalArgumentException("As observacoes não podem ficar vazia!");
        }
        this.observacoes = observacoes;
    }

    public Adotante getAdotante() {
        return adotante;
    }

    public void setAdotante(Adotante adotante) {
        this.adotante = adotante;
    }

    public Animal getAnimal() {
        return animal;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    @Override
    public String toString() {
        return "Adocao{" + "dataSolicitacao=" + dataSolicitacao + ", dataConclusao=" + dataConclusao + ", observacoes=" + observacoes + ", adotante=" + adotante + ", animal=" + animal + '}';
    }

}
