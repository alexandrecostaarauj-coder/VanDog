/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author isabf
 */
public class Animal {

    private String nome;
    private String sexo;
    private String porte;
    private String cor;
    private boolean castrado;
    private boolean vacinado;
    private String descricao;
    private StatusAdocao statusAdocao;
    private int id;
    private String foto;
    private int idAdotante;
    private int idDoador;   
    private int idOng;      

    public Animal(String nome, String sexo, String porte, String cor, boolean castrado, boolean vacinado, String descricao, StatusAdocao statusAdocao) {
        this.nome = nome;
        this.sexo = sexo;
        this.porte = porte;
        this.cor = cor;
        this.castrado = castrado;
        this.vacinado = vacinado;
        this.descricao = descricao;
        this.statusAdocao = statusAdocao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("O nome não pode ficar vazio!");
        }
        this.nome = nome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        if (sexo == null || sexo.trim().isEmpty()) {
            throw new IllegalArgumentException("O sexo não pode ficar vazio!");
        }
        this.sexo = sexo;
    }

    public String getPorte() {
        return porte;
    }

    public void setPorte(String porte) {
        if (porte == null || porte.trim().isEmpty()) {
            throw new IllegalArgumentException("O porte não pode ficar vazio!");
        }
        this.porte = porte;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        if (cor == null || cor.trim().isEmpty()) {
            throw new IllegalArgumentException("A cor não pode ficar vazia!");
        }
        this.cor = cor;
    }

    public boolean isCastrado() {
        return castrado;
    }

    public void setCastrado(boolean castrado) {
        this.castrado = castrado;
    }

    public boolean isVacinado() {
        return vacinado;
    }

    public void setVacinado(boolean vacinado) {
        this.vacinado = vacinado;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        if (descricao == null || descricao.trim().isEmpty()) {
            throw new IllegalArgumentException("A descricao não pode ficar vazia!");
        }
        this.descricao = descricao;
    }

    public StatusAdocao getStatusAdocao() {
        return statusAdocao;
    }

    public void setStatusAdocao(StatusAdocao statusAdocao) {
        this.statusAdocao = statusAdocao;
    }

    public String getFoto() {
        return foto;
    }

 
    public void setFoto(String foto) {
        this.foto = (foto == null || foto.isBlank()) ? null : foto;
    }

    public boolean temFoto() {
        return foto != null;
    }

    public int getIdAdotante() {
        return idAdotante;
    }

    public void setIdAdotante(int idAdotante) {
        this.idAdotante = idAdotante;
    }

    public int getIdDoador() {
        return idDoador;
    }

    public void setIdDoador(int idDoador) {
        this.idDoador = idDoador;
    }

    public int getIdOng() {
        return idOng;
    }

    public void setIdOng(int idOng) {
        this.idOng = idOng;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Animal{" + "nome=" + nome + ", sexo=" + sexo + ", porte=" + porte + ", cor=" + cor + ", castrado=" + castrado + ", vacinado=" + vacinado + ", descricao=" + descricao + ", statusAdocao=" + statusAdocao + '}';
    }

}
