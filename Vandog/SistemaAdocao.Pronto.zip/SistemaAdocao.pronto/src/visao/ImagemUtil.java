package visao;

import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import persistencia.FotoPersistencia;


public final class ImagemUtil {

    private ImagemUtil() {
    }

  
    public static void mostrarFoto(JLabel label, String caminho, int largura, int altura, String textoSemFoto) {
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setVerticalAlignment(SwingConstants.CENTER);

        BufferedImage imagem = FotoPersistencia.lerImagem(caminho);
        if (imagem == null) {
            label.setIcon(null);
            label.setText(textoSemFoto);
            return;
        }

     
        double escala = Math.min((double) largura / imagem.getWidth(), (double) altura / imagem.getHeight());
        int w = Math.max(1, (int) (imagem.getWidth() * escala));
        int h = Math.max(1, (int) (imagem.getHeight() * escala));

        Image reduzida = imagem.getScaledInstance(w, h, Image.SCALE_SMOOTH);
        label.setText("");
        label.setIcon(new ImageIcon(reduzida));
    }
}
